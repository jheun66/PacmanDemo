#pragma once

#include "stdafx.h"

class IWidget
{
public:
	IWidget();
	virtual ~IWidget() = default;

	virtual void Begin()
	{
		if (bVisible)
			return;

		if (size.x != -1.0f && size.y != -1.0f)
			ImGui::SetNextWindowSize(size); //������ ũ�� ����

		if ((size.x != -1.0f && size.y != -1.0f) || (size_max.x != std::numeric_limits<float>::max() && size_max.y != std::numeric_limits<float>::max()))
			ImGui::SetNextWindowSizeConstraints(size, size_max); 

		ImGui::Begin(title.c_str(), &bVisible, windowFlags);
	}

	virtual void Render() = 0;
	virtual void End()
	{
		if (bVisible)
			return;

		height = ImGui::GetWindowHeight();
		ImGui::End();
	}

	float& GetHeight() { return height; }
	const bool& IsVisible() { return bVisible; }
	void SetVisible(const bool& bVisible) { this->bVisible = bVisible; }


protected:
	string title = "";
	ImVec2 size = ImVec2(-1.0f, -1.0f);
	ImVec2 size_max = ImVec2(numeric_limits<float>::max(), numeric_limits<float>::max());
	float height = 0.0f;
	int windowFlags = ImGuiWindowFlags_NoCollapse;
	bool bVisible = true;
};