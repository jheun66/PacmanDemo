#include "stdafx.h"
#include "Widget_Slider.h"

void Widget_Slider::AddSliderFloat(string sliderName, float * value, float min, float max)
{
	
}
