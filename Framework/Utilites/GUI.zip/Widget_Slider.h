#pragma once

#include "IWidget.h"

class Widget_Slider : public IWidget
{
public:
	Widget_Slider();
	~Widget_Slider() = default;

	void Render() override;


	void AddSliderFloat(string sliderName, float* value, float min, float max);
private:
	




};